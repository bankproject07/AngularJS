import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {Component} from '@angular/core';
import { Pipe, PipeTransform} from '@angular/core';

@Pipe({name:'changeCase' })
class CustomPipe implements PipeTransform{

    transform(value:string,args:string) {
        if(args==="upper") 
        {
            return value.toUpperCase();
        }
        else{
            return value.toLowerCase();
        }
    }

}


@Component ({
    selector : 'my-app',
    template:`  
          <div>
             <h1> Pipe Demo </h1>
             <h2> Name - {{name|uppercase}} </h2>
             <h3> Name - {{name|changeCase:'lowercase'}} </h3>
             <h2> Date - {{today|date:"dd, EEEE MMMM yyyy"|uppercase}} </h2>
          </div>
        `
})
export class PipeDemoComponent {
    name:string="anil";
    today= new Date();
}
@NgModule({
    declarations: [PipeDemoComponent,CustomPipe],
    imports: [ BrowserModule ],
    bootstrap: [PipeDemoComponent]
 })
export class AppModule {}