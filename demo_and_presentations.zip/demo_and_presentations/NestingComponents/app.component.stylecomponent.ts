
import {Component} from '@angular/core';
import {FormsModule} from '@angular/forms';

@Component ({
    selector : 'my-app',
    template: ` 
               <style>
                   .custom {
                       color:red;
                       text-transform:uppercase
                   }
               </style>
               <div>
                    <h1> This is the heading </h1>
                    <h3 class="custom"> Template Inline Style </h3>
                </div>            
                <div>
                   <binding-demo> </binding-demo>
                </div>
             `,
    styles: ['h1 {color:blue}'],  
 
 })
export class StyleComponent {

}