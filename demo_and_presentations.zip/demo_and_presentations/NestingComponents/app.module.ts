import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {Component} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {StyleComponent} from './app.component.stylecomponent';
import {TwowayBindingComponent} from './app.component.twowaybinding';
@NgModule({
    declarations: [StyleComponent,TwowayBindingComponent],
    imports: [ BrowserModule,FormsModule ],
    bootstrap: [StyleComponent]
 })
export class AppModule {}