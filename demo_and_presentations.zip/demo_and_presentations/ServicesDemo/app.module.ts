import {Injectable,Inject,NgModule,OnInit} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {Component} from '@angular/core';


@Injectable()
export class EmployeeService {
    getAllEmployees() {
    return [
        {id: 5085, name:"anil"},
        { id: 6050, name:"rama" }

    ]
  }
}

@Component ({
          selector : 'my-app',
          template: ` <h1> Employee List </h1>
          <div>
               <ul>
                  <li *ngFor="let employee of employees"> {{employee.name}} </li>
               </ul>
          </div>
                  
          ` ,
        providers: [EmployeeService ]   
        
})
export class TestServiceComponent implements OnInit {

    private employees: any[];
   
    constructor(@Inject (EmployeeService) private employeeservice:EmployeeService ){
     
    }

    ngOnInit() :void {
        this.employees=  this.employeeservice.getAllEmployees();  
    }
    
}
@NgModule({
    declarations: [TestServiceComponent],
    imports: [ BrowserModule ],
    bootstrap: [TestServiceComponent]
 })
export class AppModule {}