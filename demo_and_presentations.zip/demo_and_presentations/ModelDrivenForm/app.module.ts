import {NgModule,Component,Inject} from '@angular/core'
import { BrowserModule} from '@angular/platform-browser'
import {ReactiveFormsModule,FormGroup,FormControl,FormBuilder,Validators} from '@angular/forms'

interface Person {
    personName: string;
    personAge:string;
}

export function ageValidator(control:FormControl):{ [s:string]:boolean} 
{
  if( control.value > 100 ) {
      return ({invalidAge:true})
  }

}




@Component( {
   selector: 'my-app',
   template: `
   <div>
      <h1> Model driven form </h1>
      
      <form [formGroup]= "personForm" (ngSubmit)="onSubmit()">
        Name : <input type="text" name="name"  formControlName="personName">
        <small *ngIf="personForm.controls['personName'].hasError('required')"> Name is required </small>
        <small *ngIf="personForm.controls['personName'].hasError('minlength')"> Min 4 characters required </small>
        <small *ngIf="personForm.controls['personName'].hasError('maxlength')"> Max 8 characters required </small>
  
        Age : <input type="text" name="age"  formControlName="personAge">
        <small *ngIf="personForm.controls['personAge'].hasError('required')"> Name is required </small>
        <small *ngIf="personForm.controls['personAge'].hasError('invalidAge')"> 2 digits required </small>
        
        <button type="submit"> Submit </button>

      </form>
   </div>
   `
}
)
export class ModelFormComponent {
    personForm: FormGroup;
    person:Person;
    nameControl: FormControl;

    constructor( @Inject (FormBuilder) private builder:FormBuilder){
       this.buildForm();
    }

    private buildForm() {
      this.personForm = this.builder.group({
          personName: new FormControl("Anil",
          Validators.compose([Validators.required,Validators.minLength(4),
                               Validators.maxLength(8)])
           ),
          personAge: new FormControl(20,
              Validators.compose([Validators.required,ageValidator])
          
            )
      });
    }

    onSubmit() {
        
        alert(JSON.stringify(this.personForm.value));

        this.person = this.personForm.value;

        alert("name :" + this.person.personName+ "Age : "+this.person.personAge);
       //you will send the data to server using http.post
       // that will give you response data
       // store this response in local varible and do binding of that on
       //your view

    }
}

@NgModule( {
 imports : [BrowserModule, ReactiveFormsModule],
 declarations: [ModelFormComponent],
 bootstrap:[ModelFormComponent ]
}
)
export class AppModule {

}