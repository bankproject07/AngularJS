"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var forms_1 = require("@angular/forms");
function ageValidator(control) {
    if (control.value > 100) {
        return ({ invalidAge: true });
    }
}
exports.ageValidator = ageValidator;
var ModelFormComponent = (function () {
    function ModelFormComponent(builder) {
        this.builder = builder;
        this.buildForm();
    }
    ModelFormComponent.prototype.buildForm = function () {
        this.personForm = this.builder.group({
            personName: new forms_1.FormControl("Anil", forms_1.Validators.compose([forms_1.Validators.required, forms_1.Validators.minLength(4),
                forms_1.Validators.maxLength(8)])),
            personAge: new forms_1.FormControl(20, forms_1.Validators.compose([forms_1.Validators.required, ageValidator]))
        });
    };
    ModelFormComponent.prototype.onSubmit = function () {
        alert(JSON.stringify(this.personForm.value));
        this.person = this.personForm.value;
        alert("name :" + this.person.personName + "Age : " + this.person.personAge);
        //you will send the data to server using http.post
        // that will give you response data
        // store this response in local varible and do binding of that on
        //your view
    };
    return ModelFormComponent;
}());
ModelFormComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        template: "\n   <div>\n      <h1> Model driven form </h1>\n      \n      <form [formGroup]= \"personForm\" (ngSubmit)=\"onSubmit()\">\n        Name : <input type=\"text\" name=\"name\"  formControlName=\"personName\">\n        <small *ngIf=\"personForm.controls['personName'].hasError('required')\"> Name is required </small>\n        <small *ngIf=\"personForm.controls['personName'].hasError('minlength')\"> Min 4 characters required </small>\n        <small *ngIf=\"personForm.controls['personName'].hasError('maxlength')\"> Max 8 characters required </small>\n  \n        Age : <input type=\"text\" name=\"age\"  formControlName=\"personAge\">\n        <small *ngIf=\"personForm.controls['personAge'].hasError('required')\"> Name is required </small>\n        <small *ngIf=\"personForm.controls['personAge'].hasError('invalidAge')\"> 2 digits required </small>\n        \n        <button type=\"submit\"> Submit </button>\n\n      </form>\n   </div>\n   "
    }),
    __param(0, core_1.Inject(forms_1.FormBuilder)),
    __metadata("design:paramtypes", [forms_1.FormBuilder])
], ModelFormComponent);
exports.ModelFormComponent = ModelFormComponent;
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [platform_browser_1.BrowserModule, forms_1.ReactiveFormsModule],
        declarations: [ModelFormComponent],
        bootstrap: [ModelFormComponent]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map