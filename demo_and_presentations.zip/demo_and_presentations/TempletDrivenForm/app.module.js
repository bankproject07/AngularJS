"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var forms_1 = require("@angular/forms");
var TemplateFormComponent = (function () {
    function TemplateFormComponent() {
    }
    TemplateFormComponent.prototype.onSubmit = function (person) {
        alert("name :" + person.name + "Age : " + person.age);
        //you will send the data to server using http.post
        // that will give you response data
        // store this response in local varible and do binding of that on
        //your view
    };
    return TemplateFormComponent;
}());
TemplateFormComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        template: "\n   <div>\n      <h1> Template driven form </h1>\n      <form #person=\"ngForm\" (ngSubmit)=\"onSubmit(person.value)\" novalidate>\n        <span>\n        Enter name : <input type=\"text\" id=\"name\" name=\"name\" [(ngModel)]=\"person.name\">\n        </span>\n        <span>\n        Enter Age : <input type=\"text\" id=\"age\" name=\"age\" [(ngModel)]=\"person.age\">\n        </span>\n        <span>\n        <button type=\"submit\"> Submit </button>\n        </span>\n        \n      </form>\n\n   </div>\n   "
    })
], TemplateFormComponent);
exports.TemplateFormComponent = TemplateFormComponent;
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [platform_browser_1.BrowserModule, forms_1.FormsModule],
        declarations: [TemplateFormComponent],
        bootstrap: [TemplateFormComponent]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map