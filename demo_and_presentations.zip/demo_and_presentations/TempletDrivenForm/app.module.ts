import {NgModule,Component} from '@angular/core'
import { BrowserModule} from '@angular/platform-browser'
import {FormsModule} from '@angular/forms'

interface Person {
    name: string;
    age:string;
}


@Component( {
   selector: 'my-app',
   template: `
   <div>
      <h1> Template driven form </h1>
      <form #person="ngForm" (ngSubmit)="onSubmit(person.value)" novalidate>
        <span>
        Enter name : <input type="text" id="name" name="name" [(ngModel)]="person.name">
        </span>
        <span>
        Enter Age : <input type="text" id="age" name="age" [(ngModel)]="person.age">
        </span>
        <span>
        <button type="submit"> Submit </button>
        </span>
        
      </form>

   </div>
   `
}
)
export class TemplateFormComponent {

    onSubmit(person: Person) {
        alert("name :" + person.name+ "Age : "+person.age);
       //you will send the data to server using http.post
       // that will give you response data
       // store this response in local varible and do binding of that on
       //your view

    }
}

@NgModule( {
 imports : [BrowserModule, FormsModule],
 declarations: [TemplateFormComponent],
 bootstrap:[TemplateFormComponent ]
}
)
export class AppModule {

}