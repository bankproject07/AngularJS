import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {Component} from '@angular/core';
@Component ({
    selector : 'my-app',
    template: ` 
               <div>
                   <div *ngIf="status"> 
                        Status is set to true
                    </div>    
                    <div *ngIf="!status"> 
                        Status is set to false
                    </div>    
               </div>  
               <div>
                    <h1> ng-for demo </h1>
                    <ul> 
                        <li *ngFor="let employee of employees"> {{employee.name}} </li>
                    </ul>
                    <select>
                       <option *ngFor="let employee of employees;let counter=index" [value] ="counter"> {{employee.name}} </option>
                    </select>  
                 </div>                   
             `
   })
export class DiretiveComponent {
    status:boolean=false;
    employees:any=[
         {'id':5085,'name': 'Anil'},
         {'id':5086,'name': 'Sunil'},
         { 'id':5087,'name': 'Hari'}
    ]}

@NgModule({
    declarations: [DiretiveComponent],
    imports: [ BrowserModule ],
    bootstrap: [DiretiveComponent]
 })
export class AppModule {}