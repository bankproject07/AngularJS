import { Component,Injectable,Inject,OnInit,NgModule,enableProdMode } from '@angular/core';
import { HttpModule } from '@angular/http';
import { Http,Response } from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { Observable } from 'rxjs/Observable';

import 'rxjs/Rx'; 


@Injectable()
export class GuestService{
    
    private url = 'http://localhost:3000/HttpDemo/guests.json';
    
    constructor(@Inject(Http) private http:Http){
        
    }
    
    getAllGuests():Observable<any[]>{
        return this.http.get(this.url).map((response:Response)=><any[]>response.json()).catch(this.handleError);
        
    }
    
    private handleError(error:Response){
        console.log(error);
        return Observable.throw(error.json().error || 'Server Error');
    }
}


@Component({
  selector: 'my-app',
  template: `
  <table class="table table-striped">
  <thead>
      <tr>
          <th>Id</th>
          <th>Name</th>
          <th>Contact</th>
      </tr>
  </thead>
  <tbody>
       <tr *ngFor="let guest of guests_received">
            <td>{{ guest.id }}</td>
            <td>{{ guest.name }}</td>
            <td>{{ guest.contactNumber }}</td>
        </tr>
   </tbody>
</table>
   
  `,
  providers: [ GuestService ]
})


export class GuestComponent implements OnInit{
   private guests_received:any[];
    private errorMessage:any;
    
    constructor(@Inject(GuestService) private service:GuestService){
        
    }
    
    ngOnInit():void{
         this.service.getAllGuests().subscribe(
             (guests)=> {console.log(guests); this.guests_received = guests},
             (error)=>this.errorMessage=error);
    }
}

@NgModule({
  imports:      [ BrowserModule, HttpModule ],
  declarations: [ GuestComponent ],
  bootstrap:    [ GuestComponent ]
})
export class AppModule { }



  