import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {Component} from '@angular/core';
@Component ({
    selector : 'my-app',
    template: `
         <div>
            <p> value ={{value}} </p>
            <button (click)="increment()">Increment </button>

            <div  [ngSwitch]="value">
            <p *ngSwitchCase="0">
                Zero
            </p>
            <p *ngSwitchCase="1">
               One
            </p>
            <p *ngSwitchDefault>
               default
            </p>
            
         <div> 
                             
             `
   })
export class DiretiveComponent {
  value:number=0;
  increment() {
      this.value=this.value+1;
  }

}

@NgModule({
    declarations: [DiretiveComponent],
    imports: [ BrowserModule ],
    bootstrap: [DiretiveComponent]
 })
export class AppModule {}