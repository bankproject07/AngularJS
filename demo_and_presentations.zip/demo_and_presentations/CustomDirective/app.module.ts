import { Component } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { enableProdMode } from '@angular/core';
import { NgModule } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic'
import { Directive,HostBinding,HostListener } from '@angular/core';

@Directive({
  selector: '[myDirective]'
})

export class CustomDirective {
	@HostBinding('attr.role') role="guest";
	
	 @HostListener('click', ['$event'])
	 onClick(e:any) {
		this.role=this.role=="guest"?"admin":"guest";
		e.target.innerText =this.role;
	}
}

@Component({
  selector: 'my-app',
   template: `<div>
	<h1>Custom Directive</h1>
	<hr/>
	<button myDirective>Directive Component</button>
	</div>`
})

export class DirectiveComponent {

}

@NgModule({
	imports:[ BrowserModule ],
	declarations:[ DirectiveComponent,CustomDirective ],
	bootstrap:[ DirectiveComponent ]
})
export class AppModule{}
