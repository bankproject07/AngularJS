import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {Component} from '@angular/core';
@Component ({
    selector : 'my-app',
    template:`  
            <div> 
                 Your name is {{name}}
                 <br>
                 <img [src]='photoUrl' title={{id}} />
                 <button (click)='changeImage()'>Change Image </button> 
             </div>
        `
})
export class PropertyBindigComponent {
    id:number =605085;
    name:string="Sunil";
    photourls:string[] = ['./PropertyBinding/bank1.jpg','./PropertyBinding/chris1_lg.jpg'] ;
    location:number=0;
    photoUrl:string=this.photourls[this.location];
    changeImage() : void {
        if(this.photourls.length > this.location) {
            this.location=this.location+1;
            this.photoUrl=this.photourls[this.location];  
        }      
    }
}
@NgModule({
    declarations: [PropertyBindigComponent],
    imports: [ BrowserModule ],
    bootstrap: [PropertyBindigComponent]
 })
export class AppModule {}