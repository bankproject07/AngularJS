import { Component,Inject, NgModule, enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

enableProdMode();

@Component({
  selector: 'my-app',
  template: `<h1>Factory Provider Demo</h1>
              Result - {{result }} 
            `
})

export class FactoryProviderComponent {
  private result:number;
	constructor(@Inject('AddNumbers') addfun:any){
   		this.result=addfun(4,5);
	}
}

@NgModule({
  imports:[ BrowserModule ],
  declarations:[ FactoryProviderComponent ],
  providers:[{
    provide:'AddNumbers', 
    useFactory:()=>{
      return function(a:number,b:number){
        return a+b;
       }
    }
  }],
  bootstrap:[ FactoryProviderComponent ]
})
export class AppModule{}


