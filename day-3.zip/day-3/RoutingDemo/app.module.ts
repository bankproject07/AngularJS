import { NgModule,Component,Injectable,Inject } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import {RouterModule, Routes,ActivatedRoute,Router} from "@angular/router";
import { HomeComponent } from "./components/homeComponent";
import { AboutComponent } from "./components/myaboutcomponent";
import { AppComponent } from "./components/my.appComponent";


const routes: Routes=[
    {path:'',redirectTo:'/home',pathMatch:'full'},
    {path: 'home',component: HomeComponent},
    {path: 'about/:id',component: AboutComponent    }

]

@NgModule({
  imports:[BrowserModule,RouterModule.forRoot(routes,{useHash:true})],
  declarations:[AppComponent,HomeComponent,AboutComponent],
  bootstrap:[AppComponent]
})
export class AppModule {
    
}