/**
 * 
 */

//Creating a module
var productName = angular.module('productDetail',[]);

//Creating A Controller & Registering with Module
productName.controller('ProductController',function($scope){
	
	
	$scope.products=[
{'id': 1001,'name': 'Book','price': 380},        
{'id': 1002,'name': 'Toy','price': 1000},
{'id': 1003,'name': 'Cold Drink','price':30}
];	
	});