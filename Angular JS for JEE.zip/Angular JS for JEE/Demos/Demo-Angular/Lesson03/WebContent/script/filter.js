/**
 * 
 */

/*---------------------------------------------Angular-01-Filter----------------*/

var myFilter=angular.module("filterApp",[]);

myFilter.controller("FilterController",function($scope){
	
	

	$scope.products=[
{'id': 1003,'name': 'cold Drink','price':30,"date":new Date("January 23,2016")},
{'id': 1001,'name': 'Samsung Glaxy','price': 12380,"date":new Date("March 13,2014")},        
{'id': 1002,'name': 'Toy','price': 1000,"date":new Date("April 23,2011")},
{'id': 1004,'name': 'Iphone 6S','price': 45000,"date":new Date("April 23,2015")},
{'id': 1005,'name': 'Book','price': 1000,"date":new Date("May 13,2012")},
{'id': 1006,'name': 'MicroWave','price': 11000,"date":new Date("July 12,2013")},
{'id': 1007,'name': 'Soap','price': 160,"date":new Date("April 23,2016")},
{'id': 1008,'name': 'Tooth Paste','price': 300,"date":new Date("May 03,2016")}
];	
	
	$scope.mydate=new Date();
	});

/*-------------------------------------Angular-02-Filter---------------------------------------------------------------------------------------*/

myFilter.controller("FilterControllerOne",function($scope){
	
	

	$scope.products=[
{'id': 1003,'name': 'cold Drink','price':30,"date":new Date("January 23,2016")},
{'id': 1001,'name': 'Samsung Glaxy','price': 12380,"date":new Date("March 13,2014")},        
{'id': 1002,'name': 'Toy','price': 1000,"date":new Date("April 23,2011")},
{'id': 1004,'name': 'Iphone 6S','price': 45000,"date":new Date("April 23,2015")},
{'id': 1005,'name': 'Book','price': 1000,"date":new Date("May 13,2012")},
{'id': 1006,'name': 'MicroWave','price': 11000,"date":new Date("July 12,2013")},
{'id': 1007,'name': 'Soap','price': 160,"date":new Date("April 23,2016")},
{'id': 1008,'name': 'Tooth Paste','price': 300,"date":new Date("May 03,2016")}
];	
	
	
	});

/*---------------------------------------Angular-CustomFilter---------------------------------------------*/
myFilter.filter("reverseText", function() {
	alert('Start Reversing The Text');
	return function(input) {
		 
        var result = "";
        input = input || "";

       for (var i=0; i<input.length; i++) {
              result = input.charAt(i) + result;
        }

       return result;
};
	
});



